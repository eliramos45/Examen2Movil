package com.example.examen__movil2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    Button btnBorrar, btnAgregar, btnEditar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnBorrar= findViewById(R.id.btnObtener);
        btnAgregar= findViewById(R.id.btnAgregar);
        btnEditar= findViewById(R.id.btnEditar);

        CRUDRecetas CRUD = new CRUDRecetas(this);
        ArrayList<String> listaRecetitas = new ArrayList<String>();
        //CRUD.insertarReceta("Chilaquiles", "rica comida casera");

        ListView listaRecetas=findViewById(R.id.listarecetas);
        Cursor informacion=CRUD.mostrarRecetas();

        while (informacion.moveToNext()){
            String titulo=informacion.getString(1);
            String id= informacion.getString(0);
            listaRecetitas.add(id+ " " + titulo );

        }

        ArrayAdapter<String> adaptador = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1,listaRecetitas);
        listaRecetas.setAdapter(adaptador);

        btnBorrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intentoBorrar= new Intent( MainActivity.this, borrar.class);
                startActivity(intentoBorrar);
            }
        });

        btnAgregar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intentoAgregar= new Intent( MainActivity.this, agregar.class);
                startActivity(intentoAgregar);
            }
        });

        btnEditar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intentoEditar= new Intent( MainActivity.this, editar.class);
                startActivity(intentoEditar);
            }
        });

    }
}