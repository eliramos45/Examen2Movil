package com.example.examen__movil2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;

import java.util.ArrayList;


public class agregar extends AppCompatActivity {

    Button btnAgregar2,
            btnAtras2;

    EditText etTitulo,
            etDescripcion;

    private  CRUDRecetas CRUD;

    private ArrayAdapter<String> adaptador;
    private ArrayList<String> listaRecetitas;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_agregar);



        btnAgregar2= findViewById(R.id.Btneditar2);
        btnAtras2=findViewById(R.id.btnAtras4);
        etTitulo=findViewById(R.id.etID);
        etDescripcion=findViewById(R.id.etDescripcion);

        CRUD = new CRUDRecetas(this);
        listaRecetitas = new ArrayList<>();
        adaptador = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, listaRecetitas);

        btnAgregar2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String titulo = etTitulo.getText().toString();
                String descripcion = etDescripcion.getText().toString();

                CRUD.insertarReceta( titulo, descripcion);
                actualizarRecetario();
                Intent intentoAgregar= new Intent( agregar.this, MainActivity.class);
                startActivity(intentoAgregar);
            }
        });

        btnAtras2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intentoRegresar= new Intent( agregar.this, MainActivity.class);
                startActivity(intentoRegresar);

            }
        });
    }
    private void actualizarRecetario() {
        listaRecetitas.clear();
        Cursor informacion = CRUD.mostrarRecetas();
        while (informacion.moveToNext()) {
            String titulo = informacion.getString(1);
            String id= informacion.getString(0);
            listaRecetitas.add(id + " " + titulo);
        }

    }
}
