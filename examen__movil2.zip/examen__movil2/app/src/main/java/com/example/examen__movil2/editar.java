package com.example.examen__movil2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;

import java.util.ArrayList;

public class editar extends AppCompatActivity {

    Button btnEditar2,
            btnAtras4;

    EditText etID,
            etTitulo2,
            etDescripcion2;

    private  CRUDRecetas CRUD;

    private ArrayAdapter<String> adaptador;
    private ArrayList<String> listaRecetitas;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_editar);

        btnEditar2= findViewById(R.id.Btneditar2);
        btnAtras4=findViewById(R.id.btnAtras4);
        etID=findViewById(R.id.etID);
        etTitulo2=findViewById(R.id.etTitulo2);
        etDescripcion2=findViewById(R.id.etDescripcion2);


        CRUD = new CRUDRecetas(this);
        listaRecetitas = new ArrayList<>();
        adaptador = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, listaRecetitas);


        btnEditar2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int Idnum = Integer.parseInt(etID.getText().toString());
                String nuevoTitulo = etTitulo2.getText().toString();
                String nuevadescripcion = etDescripcion2.getText().toString();
                CRUD.actualizarReceta(Idnum, nuevoTitulo, nuevadescripcion);
                actualizarRecetario();
                Intent intentoAgregar= new Intent( editar.this, MainActivity.class);
                startActivity(intentoAgregar);

            }


        });

    }

    private void actualizarRecetario() {
        listaRecetitas.clear();
        Cursor informacion = CRUD.mostrarRecetas();
        while (informacion.moveToNext()) {
            String titulo = informacion.getString(1);
            String id= informacion.getString(0);
            listaRecetitas.add(id + " " + titulo);
        }

    }
}